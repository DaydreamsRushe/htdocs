<?php

function pDump($var){
  echo "<pre>";
  var_dump($var);
  echo "</pre>";
}

?>