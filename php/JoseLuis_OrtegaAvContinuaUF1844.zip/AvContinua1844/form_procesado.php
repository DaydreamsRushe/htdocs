<?php
require_once 'assets/gestor.php';

form_validado($langresult);
?>