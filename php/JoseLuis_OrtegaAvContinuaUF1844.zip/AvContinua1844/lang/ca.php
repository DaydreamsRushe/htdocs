<?php
  //FORMULARIO
  $langform = [
    "logo" => "ReGisTreDoreitor",
    "cambiar_idioma" => "Llenguatge",
    "opcion_1" => "Seleccionar",
    "opcion_2" => "Castellano",
    "opcion_3" => "Català",
    "title" => "Formulari de Registre",
    "cambiar" => "Canviar",
    "usuari" => "Usuari",
    "correu" => "Correu",
    "errorUsuari" => "Hi ha un error en el nom d'Usuari (entre 5 i 15)",
    "errorEmail" => "El correu no s'ha introduït correctament",
    "errorEmpty" => "Alguns dels camps es es troba buit, si us plau ompliu els camps corresponents",
  ];

  //BBDD
  $langresult = [
    "logo" => "ReGisTreDoreitor",
    "cambiar_idioma" => "Llenguatge",
    "opcion_1" => "Seleccionar",
    "opcion_2" => "Castellano",
    "opcion_3" => "Català",
    "title" => "Formulari de Registre",
    "cambiar" => "Canviar",
    "titolConfirmacio" => "Confirmació del Registre",
  ];
?>