<?php
require_once 'assets/gestor.php';

login($lang_login);

?>