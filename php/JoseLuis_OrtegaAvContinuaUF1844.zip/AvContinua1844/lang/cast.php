<?php
  //FORMULARIO
  $langform = [
    "logo" => "ReGisTroDoreitor",
    "cambiar_idioma" => "Lenguaje",
    "opcion_1" => "Seleccionar",
    "opcion_2" => "Castellano",
    "opcion_3" => "Català",
    "title" => "Formulario de Registro",
    "cambiar" => "Cambiar",
    "usuari" => "Usuario",
    "correu" => "Correo",
    "errorUsuari" => "Hay un error en el nombre de Usuario (entre 5 i 15)",
    "errorEmail" => "El correo no se ha introducido correctamente",
    "errorEmpty" => "Algunos de los campos se encuentra vacio, por favor rellenad los campos correspondientes",
];

  //BBDD
  $langresult = [
   "logo" => "ReGisTroDoreitor",
    "cambiar_idioma" => "Lenguaje",
    "opcion_1" => "Seleccionar",
    "opcion_2" => "Castellano",
    "opcion_3" => "Català",
    "title" => "Formulario de Registro",
    "cambiar" => "Cambiar",
    "titolConfirmacio" => "Confirmación del Registro",
  ];
?>