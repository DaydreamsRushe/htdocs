<?php

/* 
 Ejercicio 1. Crear dos variables "pais" y "continente" y mostrar su valor por pantalla(imprimir)
 Poner en un comentario que tipo de dato tienen.
 */
$pais = "Europa (si, he dicho Europa, da gracias a que no la he escrito con h)"; //es un String
$continente = 3; //es un integer
echo var_dump($pais);

?>