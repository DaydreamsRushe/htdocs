<?php
require_once 'assets/gestor.php';

profileClient($lang_client);

?>