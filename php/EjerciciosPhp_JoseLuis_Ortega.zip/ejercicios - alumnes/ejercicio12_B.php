<?php
$genero2 = "Aventura";
$juegos2 = ["ASSASINS","CRASH","Prince of persia"];
?>