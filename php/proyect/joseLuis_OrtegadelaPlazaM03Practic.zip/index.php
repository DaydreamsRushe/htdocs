<?php
require_once 'assets/gestor.php';

indice($lang_index);

?>