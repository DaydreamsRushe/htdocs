<?php
require_once 'assets/gestor.php';

psicologos($lang_psicologos);

?>