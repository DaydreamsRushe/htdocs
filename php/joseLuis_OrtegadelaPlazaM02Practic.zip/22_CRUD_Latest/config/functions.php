<?php

// function valida_nombre_apellidos(){
//     if (!$this->validarNombre($data['nombre_apellidos'])) {
//         return ["error" => "el nombre debe contener solo letras..."];
//     };
// };