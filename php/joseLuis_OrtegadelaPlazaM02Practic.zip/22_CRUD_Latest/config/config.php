<?php
// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'usuarisrole');
define('DB_USER', 'root');
define('DB_PASS', '');
/* define('DB_TYPE', 'mysql'); */
