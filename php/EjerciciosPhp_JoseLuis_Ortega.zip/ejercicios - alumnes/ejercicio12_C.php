<?php
$genero3 = "Deportes";
$juegos3 = ["FIFA 21","PES 21","MOTO GP 21"];
?>