<?php
require_once "views/form.tpl";
?>