<?php
$variable1 = [1,2,3,4,5,5];
$variable2 = "nanai";
$variable3 = 15;
$variable4 = true;

echo "La variable 1 es " .gettype($variable1). "<br>";
echo "La variable 2 es " .gettype($variable2). "<br>";
echo "La variable 3 es " .gettype($variable3). "<br>";
echo "La variable 4 es " .gettype($variable4). "<br>";

?>