<?php
require_once 'assets/gestor.php';

profileProfesional($lang_profesional);

?>