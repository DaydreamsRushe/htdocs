<?php
require_once 'assets/gestor.php';

creaUsuario($lang_crear);

?>