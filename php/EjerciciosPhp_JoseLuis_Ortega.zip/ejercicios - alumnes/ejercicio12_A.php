<?php
$genero1 = "Accion";
$juegos1 = ["GTA","COD","PUBG"];
?>