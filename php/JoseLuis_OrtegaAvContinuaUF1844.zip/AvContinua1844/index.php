<?php
require_once 'assets/gestor.php';

formulario($langform);
?>